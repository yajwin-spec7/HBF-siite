import { Heart, Phone, FileText } from "lucide-react";

export function HeroSection() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8"
      style={{
        background: "linear-gradient(135deg, #FF6F00 0%, #FFC107 100%)",
      }}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-white">
            <div className="inline-block px-4 py-2 rounded-full border-2 border-white/30 mb-6">
              <span className="text-sm font-medium">
                Registered Charity | Est. October 2017
              </span>
            </div>
            
            <h1
              className="mb-6"
              style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "clamp(2.5rem, 5vw, 4rem)",
                lineHeight: "1.1",
              }}
            >
              Serving Community in Need
            </h1>
            
            <p className="text-lg md:text-xl mb-8 text-white/95 max-w-xl">
              The Hindu Benevolent Fund provides financial support to individuals 
              and families in dire need across Australia.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => scrollToSection("donate")}
                className="px-6 py-3 bg-white rounded-lg hover:bg-white/90 transition-all duration-200 flex items-center gap-2 shadow-lg"
                style={{ color: "#FF6F00" }}
              >
                <Heart className="w-5 h-5" />
                Donate Now
              </button>
              
              <button
                onClick={() => scrollToSection("get-help")}
                className="px-6 py-3 bg-transparent border-2 border-white text-white rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Get Help
              </button>
              
              <button
                onClick={() => scrollToSection("contact")}
                className="px-6 py-3 bg-transparent border-2 border-white text-white rounded-lg hover:bg-white/10 transition-all duration-200 flex items-center gap-2"
              >
                <FileText className="w-5 h-5" />
                Report a Case
              </button>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1562709911-a355229de124?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxJbmRpYW4lMjBjb21tdW5pdHklMjBzdXBwb3J0JTIwaGVscGluZyUyMGhhbmRzfGVufDF8fHx8MTc3MTUyNjU2OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Community support"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
