import { Calendar, MapPin } from "lucide-react";
import hospitalDonation from "figma:asset/a43946abc91655aaa8194fbe9f3b1f1356ed6e8c.png";
import wentworthville from "figma:asset/9802e760b9666ee6f35bbbd033c2a43d0669c7dd.png";
import rangaActivity from "figma:asset/177a12e02dd00ea220c2b878d396fda4b3d63e46.png";
import fijiAppeal from "figma:asset/b1443b0a7d9b936fd63c3c2a389e3af95fdbb9dc.png";
import hospitalVisit from "figma:asset/962b9c51fab8aba0d6bb92f9556b1241f84850ef.png";
import prospectMeal from "figma:asset/7636636f9816bfddc6b6c909f07c59ebb50b613d.png";

export function RecentActivitiesSection() {
  const activities = [
    {
      image: hospitalDonation,
      location: "Westmead Hospital",
      date: "12 November 2020",
      description: "Donation to Royal Alexandra Hospital for Children - Supporting young patients and their families.",
    },
    {
      image: wentworthville,
      location: "Wentworthville",
      date: "19 September 2021",
      description: "Community distribution event with volunteers providing essential supplies to families in need.",
    },
    {
      image: rangaActivity,
      location: "Community Collection",
      date: "Recent",
      description: "Volunteers coordinating donation collection and distribution efforts across Sydney.",
    },
    {
      image: fijiAppeal,
      location: "Fiji Cyclone Relief",
      date: "2021",
      description: "Emergency appeal for Fiji Cyclone victims - collecting donations and essential goods for disaster relief.",
    },
    {
      image: hospitalVisit,
      location: "Hospital Support",
      date: "Ongoing",
      description: "Compassionate bedside visits and support for community members during medical emergencies.",
    },
    {
      image: prospectMeal,
      location: "Prospect",
      date: "23 March 2021",
      description: "Community meal service - volunteers preparing and distributing food packages to those in need.",
    },
  ];

  return (
    <section id="recent-activities" className="py-20 px-4 sm:px-6 lg:px-8" style={{ backgroundColor: "#FFF8E1" }}>
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            Recent Activities
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Activities Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {activities.map((activity, index) => (
            <div
              key={index}
              className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={activity.image}
                  alt={activity.location}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div
                  className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs backdrop-blur-sm"
                  style={{ backgroundColor: "rgba(230, 81, 0, 0.9)", color: "white" }}
                >
                  {activity.date}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <MapPin className="w-4 h-4" style={{ color: "#FF6F00" }} />
                  <h3
                    className="text-lg"
                    style={{
                      fontFamily: "'Playfair Display', serif",
                      color: "#E65100",
                    }}
                  >
                    {activity.location}
                  </h3>
                </div>
                <p className="text-sm" style={{ color: "#333333" }}>
                  {activity.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-12 text-center">
          <p className="text-lg mb-4" style={{ color: "#4E342E" }}>
            Want to get involved or support our activities?
          </p>
          <button
            onClick={() => {
              const element = document.getElementById("contact");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
            className="px-8 py-3 rounded-lg transition-all duration-200 hover:shadow-lg"
            style={{
              backgroundColor: "#FF6F00",
              color: "white",
            }}
          >
            Contact Us
          </button>
        </div>
      </div>
    </section>
  );
}
