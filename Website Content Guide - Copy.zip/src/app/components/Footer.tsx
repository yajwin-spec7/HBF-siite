export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="py-12 px-4 sm:px-6 lg:px-8" style={{ backgroundColor: "#4E342E" }}>
      <div className="max-w-7xl mx-auto">
        {/* Top Divider */}
        <div className="w-full h-0.5 mb-8" style={{ backgroundColor: "#FFC107" }}></div>

        {/* Footer Content Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* About Column */}
          <div>
            <div className="mb-4">
              <h3
                className="text-2xl mb-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#FFC107",
                }}
              >
                HBF
              </h3>
              <p className="text-sm" style={{ color: "#FFE082" }}>
                Hindu Benevolent Fund
              </p>
            </div>
            <p className="mb-3" style={{ color: "#FFF8E1" }}>
              A registered charity with the ACNC, established by the Hindu Council of Australia
            </p>
            <p
              className="italic"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#FFC107",
              }}
            >
              "Serving Community in Need"
            </p>
          </div>

          {/* Quick Links Column */}
          <div>
            <h4
              className="text-lg mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#FFC107",
              }}
            >
              Quick Links
            </h4>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => scrollToSection("home")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("get-help")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                Get Help
              </button>
              <button
                onClick={() => scrollToSection("donate")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                Donate
              </button>
              <button
                onClick={() => scrollToSection("impact")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                Our Impact
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-left hover:opacity-70 transition-opacity"
                style={{ color: "#FFF8E1" }}
              >
                Contact
              </button>
            </div>
          </div>

          {/* Contact Column */}
          <div>
            <h4
              className="text-lg mb-4"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#FFC107",
              }}
            >
              Contact
            </h4>
            <div className="space-y-2">
              <div>
                <p className="text-sm mb-1" style={{ color: "#FFE082" }}>
                  Helpline
                </p>
                <a
                  href="tel:1300446387"
                  className="hover:opacity-70 transition-opacity"
                  style={{ color: "#FFF8E1" }}
                >
                  1300HINDUS (1300 446 387)
                </a>
              </div>
              <div>
                <p className="text-sm mb-1" style={{ color: "#FFE082" }}>
                  Email
                </p>
                <a
                  href="mailto:Hbf@hinducouncil.com.au"
                  className="hover:opacity-70 transition-opacity break-all"
                  style={{ color: "#FFF8E1" }}
                >
                  Hbf@hinducouncil.com.au
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 border-t text-center" style={{ borderColor: "#FFC107" }}>
          <p className="text-sm" style={{ color: "#FFE082" }}>
            © Hindu Benevolent Fund | Registered Charity ACNC | Hindu Council of Australia
          </p>
        </div>
      </div>
    </footer>
  );
}