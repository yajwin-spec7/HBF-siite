import { ShoppingBag, TrendingUp, Heart } from "lucide-react";

export function ImpactSection() {
  const caseStories = [
    {
      title: "Funeral Support",
      description:
        "HBF assisted with the funeral of a premature/stillborn baby — covering costs when a family needed it most.",
    },
    {
      title: "Student in Need",
      description:
        "A student from Pathankot, living in Harris Park, was diagnosed with cancer. HBF paid his rent, covered living expenses, arranged travel to Queensland, and purchased his ticket home to India.",
    },
    {
      title: "International Repatriation",
      description:
        "HBF assisted with the transportation of a deceased person's body back to India for family burial.",
    },
    {
      title: "Drowning Victim",
      description:
        "HBF helped cover near half-price funeral costs for a drowning victim, relieving immense burden from the family.",
    },
    {
      title: "Hospitalized Student",
      description:
        "An Indian student hospitalised in Australia received accommodation assistance and financial support through HBF.",
    },
    {
      title: "Domestic Violence Survivor",
      description:
        "HBF helped rehabilitate a woman from an immigration detention centre, supporting her path to permanent residency and a stable life through community services.",
    },
  ];

  return (
    <section id="impact" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            Our Impact
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Impact Intro */}
        <p
          className="text-center text-xl mb-16 max-w-4xl mx-auto"
          style={{ color: "#333333" }}
        >
          Since its founding, the Hindu Benevolent Fund has supported hundreds of 
          individuals and families across Australia — through grief, hardship, 
          medical emergencies, and natural disasters.
        </p>

        {/* COVID-19 Response Banner */}
        <div
          className="mb-16 p-8 md:p-12 rounded-2xl"
          style={{ backgroundColor: "#FFF8E1" }}
        >
          <div className="text-center mb-8">
            <h3
              className="text-3xl md:text-4xl mb-4 uppercase tracking-wide"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#E65100",
              }}
            >
              COVID-19 Community Response
            </h3>
            <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
          </div>

          <p className="text-lg mb-8 text-center max-w-3xl mx-auto" style={{ color: "#333333" }}>
            During the COVID-19 pandemic, HBF scaled up its support significantly:
          </p>

          {/* Key Stats */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="text-center p-6 rounded-xl" style={{ backgroundColor: "white" }}>
              <ShoppingBag className="w-12 h-12 mx-auto mb-4" style={{ color: "#FF6F00" }} />
              <p
                className="text-5xl md:text-6xl mb-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#E65100",
                }}
              >
                150,000
              </p>
              <p className="text-lg" style={{ color: "#4E342E" }}>
                Grocery Kits Distributed
              </p>
              <p className="text-sm mt-1" style={{ color: "#666666" }}>
                (beginning in Sydney)
              </p>
            </div>

            <div className="text-center p-6 rounded-xl" style={{ backgroundColor: "white" }}>
              <TrendingUp className="w-12 h-12 mx-auto mb-4" style={{ color: "#FF6F00" }} />
              <p
                className="text-3xl md:text-4xl mb-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#E65100",
                }}
              >
                Grocery Vouchers
              </p>
              <p className="text-lg" style={{ color: "#4E342E" }}>
                Woolworths & Coles
              </p>
            </div>

            <div className="text-center p-6 rounded-xl" style={{ backgroundColor: "white" }}>
              <Heart className="w-12 h-12 mx-auto mb-4" style={{ color: "#FF6F00" }} />
              <p
                className="text-3xl md:text-4xl mb-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "#E65100",
                }}
              >
                Rent Assistance
              </p>
              <p className="text-lg" style={{ color: "#4E342E" }}>
                For those unable to pay
              </p>
            </div>
          </div>

          <p className="text-center text-lg" style={{ color: "#333333" }}>
            <strong>Significant community donations received to fund relief efforts</strong>
          </p>
        </div>

        {/* Case Stories */}
        <div>
          <h3
            className="text-2xl md:text-3xl mb-8 text-center"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#4E342E",
            }}
          >
            Stories of Support
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {caseStories.map((story, index) => (
              <div
                key={index}
                className="p-6 rounded-xl border-2 hover:shadow-lg transition-all duration-200"
                style={{ backgroundColor: "#FFF8E1", borderColor: "#FFE082" }}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
                  style={{ backgroundColor: "#FF6F00" }}
                >
                  <Heart className="w-6 h-6 text-white" />
                </div>
                
                <h4
                  className="text-xl mb-3"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#E65100",
                  }}
                >
                  {story.title}
                </h4>
                
                <p style={{ color: "#333333" }}>{story.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
