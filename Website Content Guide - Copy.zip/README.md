
  # Website Content Guide

  This is a code bundle for Website Content Guide. The original project is available at https://www.figma.com/design/WlJNQIdcpp2nSpZ3toBLEx/Website-Content-Guide.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  