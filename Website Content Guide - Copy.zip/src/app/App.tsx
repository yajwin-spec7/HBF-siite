import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { GetHelpSection } from "./components/GetHelpSection";
import { DonateSection } from "./components/DonateSection";
import { ImpactSection } from "./components/ImpactSection";
import { RecentActivitiesSection } from "./components/RecentActivitiesSection";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div style={{ fontFamily: "'Inter', sans-serif" }}>
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <GetHelpSection />
        <DonateSection />
        <ImpactSection />
        <RecentActivitiesSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}