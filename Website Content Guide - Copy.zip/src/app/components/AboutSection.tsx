import { Award, Calendar, Users, Heart, HandHeart } from "lucide-react";

export function AboutSection() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8" style={{ backgroundColor: "#FFF8E1" }}>
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            About HBF
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Main Content Grid */}
        <div className="grid md:grid-cols-2 gap-12 mb-12">
          {/* About Text */}
          <div className="space-y-6">
            <p className="text-lg" style={{ color: "#333333" }}>
              The <strong style={{ color: "#E65100" }}>Hindu Benevolent Fund (HBF)</strong> is 
              a registered charity with the ACNC, established by the Hindu Council of Australia.
            </p>
            <p className="text-lg" style={{ color: "#333333" }}>
              HBF is a community initiative designed to provide financial support to individuals 
              and families in dire need — helping them meet their day-to-day expenses during difficult times.
            </p>
            <p className="text-lg" style={{ color: "#333333" }}>
              The fund is raised through community donations and distributed based on each 
              individual's or family's specific needs.
            </p>
            <p className="text-lg" style={{ color: "#333333" }}>
              HBF also connects people with additional support from government and 
              non-government agencies.
            </p>
          </div>

          {/* Key Values Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-6 rounded-xl border-2" style={{ backgroundColor: "white", borderColor: "#FFE082" }}>
              <Users className="w-10 h-10 mb-3" style={{ color: "#FF6F00" }} />
              <h4 className="font-semibold mb-2" style={{ color: "#E65100" }}>Community Driven</h4>
              <p className="text-sm" style={{ color: "#333333" }}>Powered by generous donations</p>
            </div>
            <div className="p-6 rounded-xl border-2" style={{ backgroundColor: "white", borderColor: "#FFE082" }}>
              <Heart className="w-10 h-10 mb-3" style={{ color: "#FF6F00" }} />
              <h4 className="font-semibold mb-2" style={{ color: "#E65100" }}>Compassionate</h4>
              <p className="text-sm" style={{ color: "#333333" }}>Supporting families in crisis</p>
            </div>
            <div className="p-6 rounded-xl border-2" style={{ backgroundColor: "white", borderColor: "#FFE082" }}>
              <HandHeart className="w-10 h-10 mb-3" style={{ color: "#FF6F00" }} />
              <h4 className="font-semibold mb-2" style={{ color: "#E65100" }}>Responsive</h4>
              <p className="text-sm" style={{ color: "#333333" }}>Quick assessment and support</p>
            </div>
            <div className="p-6 rounded-xl border-2" style={{ backgroundColor: "white", borderColor: "#FFE082" }}>
              <Award className="w-10 h-10 mb-3" style={{ color: "#FF6F00" }} />
              <h4 className="font-semibold mb-2" style={{ color: "#E65100" }}>Registered</h4>
              <p className="text-sm" style={{ color: "#333333" }}>ACNC approved charity</p>
            </div>
          </div>
        </div>

        {/* Establishment Callout & Tagline */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Establishment */}
          <div
            className="p-8 rounded-2xl border-2"
            style={{ backgroundColor: "white", borderColor: "#FFC107" }}
          >
            <div className="flex items-start gap-4">
              <div
                className="p-3 rounded-full"
                style={{ backgroundColor: "#FFF8E1" }}
              >
                <Calendar className="w-6 h-6" style={{ color: "#E65100" }} />
              </div>
              <div>
                <h3
                  className="mb-3 uppercase tracking-wide"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#E65100",
                  }}
                >
                  Established
                </h3>
                <p style={{ color: "#333333" }}>
                  HBF was formally launched during the <strong>Deepavali festival 
                  in October 2017</strong> by the Hindu Council of Australia — building 
                  on years of community support already provided by the Council and its members.
                </p>
              </div>
            </div>
          </div>

          {/* Tagline Badge */}
          <div
            className="p-8 rounded-2xl flex items-center justify-center"
            style={{ backgroundColor: "#FF6F00" }}
          >
            <div className="text-center">
              <Award className="w-12 h-12 mx-auto mb-4 text-white" />
              <p
                className="text-2xl md:text-3xl text-white"
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                "Serving Community in Need"
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}