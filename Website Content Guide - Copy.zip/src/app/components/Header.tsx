import { Menu, X } from "lucide-react";
import { useState } from "react";
import logo from "figma:asset/3f7fa274d93ea54cd679ba2cc92d8382e8476434.png";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <button
            onClick={() => scrollToSection("home")}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img
              src={logo}
              alt="Hindu Benevolent Fund"
              className="h-16 w-auto"
            />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollToSection("home")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              About
            </button>
            <button
              onClick={() => scrollToSection("get-help")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Get Help
            </button>
            <button
              onClick={() => scrollToSection("donate")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Donate
            </button>
            <button
              onClick={() => scrollToSection("impact")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Impact
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Contact
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6" style={{ color: "#E65100" }} />
            ) : (
              <Menu className="h-6 w-6" style={{ color: "#E65100" }} />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-3">
            <button
              onClick={() => scrollToSection("home")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              About
            </button>
            <button
              onClick={() => scrollToSection("get-help")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Get Help
            </button>
            <button
              onClick={() => scrollToSection("donate")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Donate
            </button>
            <button
              onClick={() => scrollToSection("impact")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Impact
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-left py-2 hover:opacity-70 transition-opacity"
              style={{ color: "#4E342E" }}
            >
              Contact
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}