import { Users, Heart, Home, Umbrella, Stethoscope, Baby, CloudRain, Phone, FileCheck, HandHeart, ExternalLink } from "lucide-react";

export function GetHelpSection() {
  const eligibleCategories = [
    { icon: Users, text: "Students going through financial hardship" },
    { icon: Home, text: "Families facing unexpected expenses" },
    { icon: Heart, text: "Individuals requiring funeral assistance" },
    { icon: Umbrella, text: "Victims of domestic violence" },
    { icon: CloudRain, text: "Victims of natural disasters" },
    { icon: Stethoscope, text: "Those facing high medical expenses" },
    { icon: Baby, text: "Parents facing unexpected parenting costs" },
    { icon: Heart, text: "Families in bereavement" },
  ];

  const processSteps = [
    {
      number: "1",
      title: "Report a Case",
      description:
        "Any community member can report a case of someone in need. Call 1300HINDUS (1300 446 387) or contact us directly.",
      icon: Phone,
    },
    {
      number: "2",
      title: "Assessment",
      description:
        "A dedicated HBF team reviews the case and assesses the individual's or family's needs.",
      icon: FileCheck,
    },
    {
      number: "3",
      title: "Support Provided",
      description:
        "Funds and assistance are allocated based on merit and available resources at that time.",
      icon: HandHeart,
    },
    {
      number: "4",
      title: "Additional Resources",
      description:
        "HBF also connects individuals with government and non-government support agencies.",
      icon: ExternalLink,
    },
  ];

  return (
    <section id="get-help" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            How to Get Help
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Who Can Apply */}
        <div className="mb-16">
          <h3
            className="text-2xl mb-8 text-center"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#4E342E",
            }}
          >
            Who Can Apply?
          </h3>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {eligibleCategories.map((category, index) => {
              const Icon = category.icon;
              return (
                <div
                  key={index}
                  className="p-6 rounded-xl border-2 hover:shadow-lg transition-all duration-200"
                  style={{ borderColor: "#FFE082", backgroundColor: "#FFF8E1" }}
                >
                  <Icon className="w-8 h-8 mb-3" style={{ color: "#FF6F00" }} />
                  <p style={{ color: "#333333" }}>{category.text}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* How It Works */}
        <div>
          <h3
            className="text-2xl mb-8 text-center"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#4E342E",
            }}
          >
            How the Process Works
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="relative">
                  {/* Connecting Line (Desktop only) */}
                  {index < processSteps.length - 1 && (
                    <div
                      className="hidden lg:block absolute top-12 left-full w-full h-0.5 -translate-x-1/2"
                      style={{ backgroundColor: "#FFC107" }}
                    ></div>
                  )}
                  
                  {/* Step Card */}
                  <div className="relative z-10">
                    {/* Step Number Circle */}
                    <div
                      className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 border-4"
                      style={{
                        backgroundColor: "#FF6F00",
                        borderColor: "#FFC107",
                      }}
                    >
                      <span className="text-4xl text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
                        {step.number}
                      </span>
                    </div>
                    
                    {/* Icon */}
                    <div className="flex justify-center mb-3">
                      <Icon className="w-8 h-8" style={{ color: "#E65100" }} />
                    </div>
                    
                    {/* Title */}
                    <h4
                      className="text-xl mb-2 text-center"
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        color: "#E65100",
                      }}
                    >
                      {step.title}
                    </h4>
                    
                    {/* Description */}
                    <p className="text-center" style={{ color: "#333333" }}>
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
