import { Building2, Calendar, Gift, Bell, Heart } from "lucide-react";

export function DonateSection() {
  return (
    <section
      id="donate"
      className="py-20 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: "#FFF8E1" }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            Donate
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Intro Text */}
        <p
          className="text-center text-xl mb-12 max-w-3xl mx-auto"
          style={{ color: "#333333" }}
        >
          Your donation helps us respond quickly to families and individuals in 
          their most vulnerable moments. Every contribution — big or small — makes 
          a real difference.
        </p>

        {/* Bank Details - Highlighted Box */}
        <div
          className="max-w-2xl mx-auto p-8 md:p-12 rounded-2xl border-4 mb-12 shadow-xl"
          style={{ backgroundColor: "#FFF8E1", borderColor: "#FFC107" }}
        >
          <div className="flex items-center justify-center mb-6">
            <Building2 className="w-12 h-12" style={{ color: "#E65100" }} />
          </div>
          
          <h3
            className="text-2xl md:text-3xl mb-6 text-center"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#E65100",
            }}
          >
            Donate via Bank Transfer
          </h3>

          <div className="space-y-4 text-center">
            <div>
              <p className="text-sm mb-1" style={{ color: "#4E342E" }}>
                Bank
              </p>
              <p className="text-xl" style={{ color: "#333333" }}>
                Commonwealth Bank of Australia
              </p>
            </div>

            <div>
              <p className="text-sm mb-1" style={{ color: "#4E342E" }}>
                Account Name
              </p>
              <p className="text-xl" style={{ color: "#333333" }}>
                HCA Benevolent Fund
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6 pt-4">
              <div>
                <p className="text-sm mb-1" style={{ color: "#4E342E" }}>
                  <strong>BSB</strong>
                </p>
                <p
                  className="text-2xl md:text-3xl"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#E65100",
                  }}
                >
                  062004
                </p>
              </div>
              <div>
                <p className="text-sm mb-1" style={{ color: "#4E342E" }}>
                  <strong>Account</strong>
                </p>
                <p
                  className="text-2xl md:text-3xl"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    color: "#E65100",
                  }}
                >
                  10447020
                </p>
              </div>
            </div>
          </div>

          {/* Optional CTA Button */}
          <div className="mt-8 text-center">
            <button
              className="px-8 py-3 rounded-lg transition-all duration-200 hover:shadow-lg"
              style={{
                backgroundColor: "#FF6F00",
                color: "white",
              }}
              onClick={() => {
                const element = document.getElementById("contact");
                if (element) {
                  element.scrollIntoView({ behavior: "smooth" });
                }
              }}
            >
              <span className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                I've Made a Transfer — Notify Us
              </span>
            </button>
          </div>
        </div>

        {/* Other Donation Methods */}
        <div>
          <h3
            className="text-xl mb-6 text-center"
            style={{
              fontFamily: "'Playfair Display', serif",
              color: "#4E342E",
            }}
          >
            Other Donation Methods
          </h3>

          <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <div
              className="p-6 rounded-xl text-center border-2"
              style={{ backgroundColor: "white", borderColor: "#FFE082" }}
            >
              <Gift className="w-10 h-10 mx-auto mb-3" style={{ color: "#FF6F00" }} />
              <p style={{ color: "#333333" }}>Community donations</p>
            </div>

            <div
              className="p-6 rounded-xl text-center border-2"
              style={{ backgroundColor: "white", borderColor: "#FFE082" }}
            >
              <Heart className="w-10 h-10 mx-auto mb-3" style={{ color: "#FF6F00" }} />
              <p style={{ color: "#333333" }}>Appeals for specific cases</p>
            </div>

            <div
              className="p-6 rounded-xl text-center border-2"
              style={{ backgroundColor: "white", borderColor: "#FFE082" }}
            >
              <Calendar className="w-10 h-10 mx-auto mb-3" style={{ color: "#FF6F00" }} />
              <p style={{ color: "#333333" }}>Fundraising events</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}