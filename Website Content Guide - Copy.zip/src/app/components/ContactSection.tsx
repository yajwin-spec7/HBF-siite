import { Phone, Mail, AlertCircle } from "lucide-react";

export function ContactSection() {
  return (
    <section
      id="contact"
      className="py-20 px-4 sm:px-6 lg:px-8"
      style={{ backgroundColor: "#FFF8E1" }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2
            className="mb-4 uppercase tracking-wide"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 4vw, 2.5rem)",
              color: "#E65100",
            }}
          >
            Contact & Helpline
          </h2>
          <div className="w-24 h-1 mx-auto" style={{ backgroundColor: "#FFC107" }}></div>
        </div>

        {/* Contact Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-12 max-w-4xl mx-auto">
          {/* Helpline */}
          <div
            className="p-8 rounded-xl text-center border-2"
            style={{ backgroundColor: "white", borderColor: "#FFE082" }}
          >
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: "#FF6F00" }}
            >
              <Phone className="w-8 h-8 text-white" />
            </div>
            <h3
              className="text-xl mb-3"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#E65100",
              }}
            >
              Helpline
            </h3>
            <p className="text-sm mb-2" style={{ color: "#4E342E" }}>
              1300HINDUS
            </p>
            <a
              href="tel:1300446387"
              className="text-2xl hover:opacity-70 transition-opacity"
              style={{ color: "#333333" }}
            >
              1300 446 387
            </a>
          </div>

          {/* Email */}
          <div
            className="p-8 rounded-xl text-center border-2"
            style={{ backgroundColor: "white", borderColor: "#FFE082" }}
          >
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: "#FF6F00" }}
            >
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h3
              className="text-xl mb-3"
              style={{
                fontFamily: "'Playfair Display', serif",
                color: "#E65100",
              }}
            >
              Email
            </h3>
            <a
              href="mailto:Hbf@hinducouncil.com.au"
              className="text-lg hover:opacity-70 transition-opacity break-all"
              style={{ color: "#333333" }}
            >
              Hbf@hinducouncil.com.au
            </a>
          </div>
        </div>

        {/* Report a Case CTA Banner */}
        <div
          className="p-8 md:p-12 rounded-2xl text-center"
          style={{ backgroundColor: "#FF6F00" }}
        >
          <AlertCircle className="w-12 h-12 mx-auto mb-4 text-white" />
          
          <h3
            className="text-3xl md:text-4xl mb-4 text-white uppercase tracking-wide"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Know Someone in Need?
          </h3>
          
          <p className="text-lg md:text-xl mb-6 text-white/95 max-w-3xl mx-auto">
            Community members are encouraged to report cases of individuals or 
            families requiring support. No case is too small — reach out and we 
            will assess how we can help.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="tel:1300446387"
              className="px-8 py-4 bg-white rounded-lg hover:bg-white/90 transition-all duration-200 inline-flex items-center gap-2 shadow-lg"
              style={{ color: "#FF6F00" }}
            >
              <Phone className="w-5 h-5" />
              <span>
                Call: <strong>1300 446 387</strong>
              </span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}